﻿# Збережіть список таблиць в змінну $tableNames
$tableNames = Invoke-Sqlcmd -Query "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'" -ServerInstance "localhost" -Database "ManufacturingDB"

# Пройдіть по кожній таблиці в списку
foreach ($tableName in $tableNames.TABLE_NAME) {
    dotnet aspnet-codegenerator controller -name "$($tableName)Controller" -m $tableName -dc ManufacturingDBContext --relativeFolderPath Controllers --useDefaultLayout --referenceScriptLibraries 
}