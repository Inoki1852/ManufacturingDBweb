using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class ManufacturingController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public ManufacturingController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: Manufacturing
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.Manufacturings.Include(m => m.IdCycleNavigation).Include(m => m.IdProductNavigation).Include(m => m.IdSectionNavigation).Include(m => m.IdTeamNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: Manufacturing/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var manufacturing = await _context.Manufacturings
                .Include(m => m.IdCycleNavigation)
                .Include(m => m.IdProductNavigation)
                .Include(m => m.IdSectionNavigation)
                .Include(m => m.IdTeamNavigation)
                .FirstOrDefaultAsync(m => m.IdManufacturing == id);
            if (manufacturing == null)
            {
                return NotFound();
            }

            return View(manufacturing);
        }

        // GET: Manufacturing/Create
        public IActionResult Create()
        {
            ViewData["IdCycle"] = new SelectList(_context.WorkCycles, "IdCycle", "IdCycle");
            ViewData["IdProduct"] = new SelectList(_context.Products, "IdProduct", "IdProduct");
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection");
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam");
            return View();
        }

        // POST: Manufacturing/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdManufacturing,IdProduct,IdSection,IdTeam,IdCycle,TimeStart,TimeEnd")] Manufacturing manufacturing)
        {
            if (ModelState.IsValid)
            {
                _context.Add(manufacturing);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCycle"] = new SelectList(_context.WorkCycles, "IdCycle", "IdCycle", manufacturing.IdCycle);
            ViewData["IdProduct"] = new SelectList(_context.Products, "IdProduct", "IdProduct", manufacturing.IdProduct);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", manufacturing.IdSection);
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam", manufacturing.IdTeam);
            return View(manufacturing);
        }

        // GET: Manufacturing/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var manufacturing = await _context.Manufacturings.FindAsync(id);
            if (manufacturing == null)
            {
                return NotFound();
            }
            ViewData["IdCycle"] = new SelectList(_context.WorkCycles, "IdCycle", "IdCycle", manufacturing.IdCycle);
            ViewData["IdProduct"] = new SelectList(_context.Products, "IdProduct", "IdProduct", manufacturing.IdProduct);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", manufacturing.IdSection);
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam", manufacturing.IdTeam);
            return View(manufacturing);
        }

        // POST: Manufacturing/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdManufacturing,IdProduct,IdSection,IdTeam,IdCycle,TimeStart,TimeEnd")] Manufacturing manufacturing)
        {
            if (id != manufacturing.IdManufacturing)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(manufacturing);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ManufacturingExists(manufacturing.IdManufacturing))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCycle"] = new SelectList(_context.WorkCycles, "IdCycle", "IdCycle", manufacturing.IdCycle);
            ViewData["IdProduct"] = new SelectList(_context.Products, "IdProduct", "IdProduct", manufacturing.IdProduct);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", manufacturing.IdSection);
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam", manufacturing.IdTeam);
            return View(manufacturing);
        }

        // GET: Manufacturing/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var manufacturing = await _context.Manufacturings
                .Include(m => m.IdCycleNavigation)
                .Include(m => m.IdProductNavigation)
                .Include(m => m.IdSectionNavigation)
                .Include(m => m.IdTeamNavigation)
                .FirstOrDefaultAsync(m => m.IdManufacturing == id);
            if (manufacturing == null)
            {
                return NotFound();
            }

            return View(manufacturing);
        }

        // POST: Manufacturing/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var manufacturing = await _context.Manufacturings.FindAsync(id);
            if (manufacturing != null)
            {
                _context.Manufacturings.Remove(manufacturing);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ManufacturingExists(int id)
        {
            return _context.Manufacturings.Any(e => e.IdManufacturing == id);
        }
    }
}
