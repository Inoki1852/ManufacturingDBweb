using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class TestingEquipmentController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public TestingEquipmentController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: TestingEquipment
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.TestingEquipments.Include(t => t.IdEquipmentNavigation).Include(t => t.IdTestingNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: TestingEquipment/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var testingEquipment = await _context.TestingEquipments
                .Include(t => t.IdEquipmentNavigation)
                .Include(t => t.IdTestingNavigation)
                .FirstOrDefaultAsync(m => m.IdTesting == id);
            if (testingEquipment == null)
            {
                return NotFound();
            }

            return View(testingEquipment);
        }

        // GET: TestingEquipment/Create
        public IActionResult Create()
        {
            ViewData["IdEquipment"] = new SelectList(_context.Equipment, "IdEquipment", "IdEquipment");
            ViewData["IdTesting"] = new SelectList(_context.Testings, "IdTesting", "IdTesting");
            return View();
        }

        // POST: TestingEquipment/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdTesting,IdEquipment")] TestingEquipment testingEquipment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(testingEquipment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEquipment"] = new SelectList(_context.Equipment, "IdEquipment", "IdEquipment", testingEquipment.IdEquipment);
            ViewData["IdTesting"] = new SelectList(_context.Testings, "IdTesting", "IdTesting", testingEquipment.IdTesting);
            return View(testingEquipment);
        }

        // GET: TestingEquipment/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var testingEquipment = await _context.TestingEquipments.FindAsync(id);
            if (testingEquipment == null)
            {
                return NotFound();
            }
            ViewData["IdEquipment"] = new SelectList(_context.Equipment, "IdEquipment", "IdEquipment", testingEquipment.IdEquipment);
            ViewData["IdTesting"] = new SelectList(_context.Testings, "IdTesting", "IdTesting", testingEquipment.IdTesting);
            return View(testingEquipment);
        }

        // POST: TestingEquipment/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdTesting,IdEquipment")] TestingEquipment testingEquipment)
        {
            if (id != testingEquipment.IdTesting)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(testingEquipment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TestingEquipmentExists(testingEquipment.IdTesting))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEquipment"] = new SelectList(_context.Equipment, "IdEquipment", "IdEquipment", testingEquipment.IdEquipment);
            ViewData["IdTesting"] = new SelectList(_context.Testings, "IdTesting", "IdTesting", testingEquipment.IdTesting);
            return View(testingEquipment);
        }

        // GET: TestingEquipment/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var testingEquipment = await _context.TestingEquipments
                .Include(t => t.IdEquipmentNavigation)
                .Include(t => t.IdTestingNavigation)
                .FirstOrDefaultAsync(m => m.IdTesting == id);
            if (testingEquipment == null)
            {
                return NotFound();
            }

            return View(testingEquipment);
        }

        // POST: TestingEquipment/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var testingEquipment = await _context.TestingEquipments.FindAsync(id);
            if (testingEquipment != null)
            {
                _context.TestingEquipments.Remove(testingEquipment);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TestingEquipmentExists(int id)
        {
            return _context.TestingEquipments.Any(e => e.IdTesting == id);
        }
    }
}
