using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class PersonnelMovementController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public PersonnelMovementController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: PersonnelMovement
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.PersonnelMovements.Include(p => p.IdEmployeeNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: PersonnelMovement/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personnelMovement = await _context.PersonnelMovements
                .Include(p => p.IdEmployeeNavigation)
                .FirstOrDefaultAsync(m => m.IdMovement == id);
            if (personnelMovement == null)
            {
                return NotFound();
            }

            return View(personnelMovement);
        }

        // GET: PersonnelMovement/Create
        public IActionResult Create()
        {
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee");
            return View();
        }

        // POST: PersonnelMovement/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdMovement,IdEmployee,MovementType,MovementDate,Details")] PersonnelMovement personnelMovement)
        {
            if (ModelState.IsValid)
            {
                _context.Add(personnelMovement);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", personnelMovement.IdEmployee);
            return View(personnelMovement);
        }

        // GET: PersonnelMovement/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personnelMovement = await _context.PersonnelMovements.FindAsync(id);
            if (personnelMovement == null)
            {
                return NotFound();
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", personnelMovement.IdEmployee);
            return View(personnelMovement);
        }

        // POST: PersonnelMovement/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdMovement,IdEmployee,MovementType,MovementDate,Details")] PersonnelMovement personnelMovement)
        {
            if (id != personnelMovement.IdMovement)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(personnelMovement);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PersonnelMovementExists(personnelMovement.IdMovement))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", personnelMovement.IdEmployee);
            return View(personnelMovement);
        }

        // GET: PersonnelMovement/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personnelMovement = await _context.PersonnelMovements
                .Include(p => p.IdEmployeeNavigation)
                .FirstOrDefaultAsync(m => m.IdMovement == id);
            if (personnelMovement == null)
            {
                return NotFound();
            }

            return View(personnelMovement);
        }

        // POST: PersonnelMovement/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var personnelMovement = await _context.PersonnelMovements.FindAsync(id);
            if (personnelMovement != null)
            {
                _context.PersonnelMovements.Remove(personnelMovement);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PersonnelMovementExists(int id)
        {
            return _context.PersonnelMovements.Any(e => e.IdMovement == id);
        }
    }
}
