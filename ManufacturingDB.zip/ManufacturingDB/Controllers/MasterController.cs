using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class MasterController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public MasterController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: Master
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.Masters.Include(m => m.IdEmployeeNavigation).Include(m => m.IdSectionNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: Master/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var master = await _context.Masters
                .Include(m => m.IdEmployeeNavigation)
                .Include(m => m.IdSectionNavigation)
                .FirstOrDefaultAsync(m => m.IdMaster == id);
            if (master == null)
            {
                return NotFound();
            }

            return View(master);
        }

        // GET: Master/Create
        public IActionResult Create()
        {
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee");
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection");
            return View();
        }

        // POST: Master/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdMaster,IdEmployee,IdSection")] Master master)
        {
            if (ModelState.IsValid)
            {
                _context.Add(master);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", master.IdEmployee);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", master.IdSection);
            return View(master);
        }

        // GET: Master/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var master = await _context.Masters.FindAsync(id);
            if (master == null)
            {
                return NotFound();
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", master.IdEmployee);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", master.IdSection);
            return View(master);
        }

        // POST: Master/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdMaster,IdEmployee,IdSection")] Master master)
        {
            if (id != master.IdMaster)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(master);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MasterExists(master.IdMaster))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", master.IdEmployee);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", master.IdSection);
            return View(master);
        }

        // GET: Master/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var master = await _context.Masters
                .Include(m => m.IdEmployeeNavigation)
                .Include(m => m.IdSectionNavigation)
                .FirstOrDefaultAsync(m => m.IdMaster == id);
            if (master == null)
            {
                return NotFound();
            }

            return View(master);
        }

        // POST: Master/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var master = await _context.Masters.FindAsync(id);
            if (master != null)
            {
                _context.Masters.Remove(master);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MasterExists(int id)
        {
            return _context.Masters.Any(e => e.IdMaster == id);
        }
    }
}
