using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class EmployeeSpecificAttributeController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public EmployeeSpecificAttributeController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: EmployeeSpecificAttribute
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.EmployeeSpecificAttributes.Include(e => e.IdAttributeTypeNavigation).Include(e => e.IdEmployeeNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: EmployeeSpecificAttribute/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeSpecificAttribute = await _context.EmployeeSpecificAttributes
                .Include(e => e.IdAttributeTypeNavigation)
                .Include(e => e.IdEmployeeNavigation)
                .FirstOrDefaultAsync(m => m.IdEmployee == id);
            if (employeeSpecificAttribute == null)
            {
                return NotFound();
            }

            return View(employeeSpecificAttribute);
        }

        // GET: EmployeeSpecificAttribute/Create
        public IActionResult Create()
        {
            ViewData["IdAttributeType"] = new SelectList(_context.AttributeTypes, "IdAttributeType", "IdAttributeType");
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee");
            return View();
        }

        // POST: EmployeeSpecificAttribute/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdEmployee,IdAttributeType,AttributeValue")] EmployeeSpecificAttribute employeeSpecificAttribute)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employeeSpecificAttribute);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdAttributeType"] = new SelectList(_context.AttributeTypes, "IdAttributeType", "IdAttributeType", employeeSpecificAttribute.IdAttributeType);
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", employeeSpecificAttribute.IdEmployee);
            return View(employeeSpecificAttribute);
        }

        // GET: EmployeeSpecificAttribute/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeSpecificAttribute = await _context.EmployeeSpecificAttributes.FindAsync(id);
            if (employeeSpecificAttribute == null)
            {
                return NotFound();
            }
            ViewData["IdAttributeType"] = new SelectList(_context.AttributeTypes, "IdAttributeType", "IdAttributeType", employeeSpecificAttribute.IdAttributeType);
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", employeeSpecificAttribute.IdEmployee);
            return View(employeeSpecificAttribute);
        }

        // POST: EmployeeSpecificAttribute/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdEmployee,IdAttributeType,AttributeValue")] EmployeeSpecificAttribute employeeSpecificAttribute)
        {
            if (id != employeeSpecificAttribute.IdEmployee)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employeeSpecificAttribute);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeSpecificAttributeExists(employeeSpecificAttribute.IdEmployee))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdAttributeType"] = new SelectList(_context.AttributeTypes, "IdAttributeType", "IdAttributeType", employeeSpecificAttribute.IdAttributeType);
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", employeeSpecificAttribute.IdEmployee);
            return View(employeeSpecificAttribute);
        }

        // GET: EmployeeSpecificAttribute/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeSpecificAttribute = await _context.EmployeeSpecificAttributes
                .Include(e => e.IdAttributeTypeNavigation)
                .Include(e => e.IdEmployeeNavigation)
                .FirstOrDefaultAsync(m => m.IdEmployee == id);
            if (employeeSpecificAttribute == null)
            {
                return NotFound();
            }

            return View(employeeSpecificAttribute);
        }

        // POST: EmployeeSpecificAttribute/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employeeSpecificAttribute = await _context.EmployeeSpecificAttributes.FindAsync(id);
            if (employeeSpecificAttribute != null)
            {
                _context.EmployeeSpecificAttributes.Remove(employeeSpecificAttribute);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeSpecificAttributeExists(int id)
        {
            return _context.EmployeeSpecificAttributes.Any(e => e.IdEmployee == id);
        }
    }
}
