using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class TeamMemberController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public TeamMemberController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: TeamMember
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.TeamMembers.Include(t => t.IdEmployeeNavigation).Include(t => t.IdTeamNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: TeamMember/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var teamMember = await _context.TeamMembers
                .Include(t => t.IdEmployeeNavigation)
                .Include(t => t.IdTeamNavigation)
                .FirstOrDefaultAsync(m => m.IdTeamMember == id);
            if (teamMember == null)
            {
                return NotFound();
            }

            return View(teamMember);
        }

        // GET: TeamMember/Create
        public IActionResult Create()
        {
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee");
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam");
            return View();
        }

        // POST: TeamMember/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdTeamMember,IdEmployee,IdTeam")] TeamMember teamMember)
        {
            if (ModelState.IsValid)
            {
                _context.Add(teamMember);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", teamMember.IdEmployee);
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam", teamMember.IdTeam);
            return View(teamMember);
        }

        // GET: TeamMember/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var teamMember = await _context.TeamMembers.FindAsync(id);
            if (teamMember == null)
            {
                return NotFound();
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", teamMember.IdEmployee);
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam", teamMember.IdTeam);
            return View(teamMember);
        }

        // POST: TeamMember/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdTeamMember,IdEmployee,IdTeam")] TeamMember teamMember)
        {
            if (id != teamMember.IdTeamMember)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(teamMember);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TeamMemberExists(teamMember.IdTeamMember))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", teamMember.IdEmployee);
            ViewData["IdTeam"] = new SelectList(_context.Teams, "IdTeam", "IdTeam", teamMember.IdTeam);
            return View(teamMember);
        }

        // GET: TeamMember/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var teamMember = await _context.TeamMembers
                .Include(t => t.IdEmployeeNavigation)
                .Include(t => t.IdTeamNavigation)
                .FirstOrDefaultAsync(m => m.IdTeamMember == id);
            if (teamMember == null)
            {
                return NotFound();
            }

            return View(teamMember);
        }

        // POST: TeamMember/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var teamMember = await _context.TeamMembers.FindAsync(id);
            if (teamMember != null)
            {
                _context.TeamMembers.Remove(teamMember);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TeamMemberExists(int id)
        {
            return _context.TeamMembers.Any(e => e.IdTeamMember == id);
        }
    }
}
