using ManufacturingDB.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;
using System.Data;


namespace ManufacturingDB.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ManufacturingDBContext _context;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, ManufacturingDBContext context,
            IConfiguration configuration)
        {
            _logger = logger;
            _context = context;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            var tableNames = _context.Model.GetEntityTypes()
                .Select(t => t.GetTableName())
                .Distinct()
                .ToList();

            var storedProcedures = new List<StoredProcedure>
            {
                new StoredProcedure { Name = "GetProductsByTypeAndWorkshop" },
                new StoredProcedure { Name = "GetEmployeesByWorkshopAndType" },
                new StoredProcedure { Name = "GetSectionsCountAndList" },
                new StoredProcedure { Name = "GetWorkCyclesForProduct" },
                new StoredProcedure { Name = "GetTeamMembersBySectionOrWorkshop" },
                new StoredProcedure { Name = "GetMastersBySectionOrWorkshop" },
                new StoredProcedure { Name = "GetCurrentProductsBySectionWorkshopOrType" },
                new StoredProcedure { Name = "GetTeamsForProduct" },
                new StoredProcedure { Name = "GetTestedProductsByLaboratoryAndType" },
                new StoredProcedure { Name = "GetTestersByProductLabAndType" },
                new StoredProcedure { Name = "GetTestingEquipmentByProductLabAndType" },
                new StoredProcedure { Name = "GetCurrentProductsCountAndList" }
            };

            var functions = new List<Function>
            {
                new Function { Name = "GetProductsCountAndList" },
                new Function { Name = "GetTestingLaboratoriesForProduct" }
            };

            var model = new HomeViewModel
            {
                TableNames = tableNames,
                StoredProcedures = storedProcedures,
                Functions = functions
            };

            return View(model);
        }

        public class StoredProcedureParameter
        {
            public string? Name { get; set; }
            public string? Type { get; set; }
            public string? Value { get; set; }
        }

        public IActionResult Procedure(string procedureName)
        {
            var connectionString = _configuration.GetConnectionString("ManufacturingDB");
            var parameters = GetProcedureParameters(connectionString, procedureName);

            var model = new StoredProcedureViewModel
            {
                Name = procedureName,
                Parameters = parameters
            };

            return View(model);
        }

        private List<StoredProcedureParameter> GetProcedureParameters(string connectionString, string procedureName)
        {
            var parameters = new List<StoredProcedureParameter>();

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand($"SELECT PARAMETER_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME = '{procedureName}'", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            parameters.Add(new StoredProcedureParameter
                            {
                                Name = reader.GetString(0).TrimStart('@'),
                                Type = reader.GetString(1)
                            });
                        }
                    }
                }
            }

            return parameters;
        }

        public IActionResult Function(string functionName)
        {
            var connectionString = _configuration.GetConnectionString("ManufacturingDB");
            var parameters = GetFunctionParameters(connectionString, functionName);

            var model = new FunctionViewModel
            {
                Name = functionName,
                Parameters = parameters
            };

            return View(model);
        }

        private List<StoredProcedureParameter> GetFunctionParameters(string connectionString, string functionName)
        {
            var parameters = new List<StoredProcedureParameter>();

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand($"SELECT PARAMETER_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME = '{functionName}'", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            parameters.Add(new StoredProcedureParameter
                            {
                                Name = reader.GetString(0).TrimStart('@'),
                                Type = reader.GetString(1)
                            });
                        }
                    }
                }
            }

            return parameters;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private List<StoredProcedure> GetStoredProcedures()
        {
            var storedProcedures = new List<StoredProcedure>();
            using (var connection = new SqlConnection(_configuration.GetConnectionString("ManufacturingDB")))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT name FROM sys.procedures WHERE is_ms_shipped = 0", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storedProcedures.Add(new StoredProcedure { Name = reader.GetString(0) });
                        }
                    }
                }
            }
            return storedProcedures;
        }

        private List<Function> GetFunctions()
        {
            var functions = new List<Function>();
            using (var connection = new SqlConnection(_configuration.GetConnectionString("ManufacturingDB")))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT name FROM sys.objects WHERE type in ('FN', 'IF', 'TF')", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            functions.Add(new Function { Name = reader.GetString(0) });
                        }
                    }
                }
            }
            return functions;
        }

        private Type GetTypeFromSqlDbType(SqlDbType sqlDbType)
        {
            switch (sqlDbType)
            {
                case SqlDbType.BigInt: return typeof(long);
                case SqlDbType.Binary: return typeof(byte[]);
                case SqlDbType.Bit: return typeof(bool);
                case SqlDbType.Char: return typeof(string);
                case SqlDbType.Date: return typeof(DateTime);
                case SqlDbType.DateTime: return typeof(DateTime);
                case SqlDbType.DateTime2: return typeof(DateTime);
                case SqlDbType.Decimal: return typeof(decimal);
                case SqlDbType.Float: return typeof(double);
                case SqlDbType.Image: return typeof(byte[]);
                case SqlDbType.Int: return typeof(int);
                case SqlDbType.Money: return typeof(decimal);
                case SqlDbType.NChar: return typeof(string);
                case SqlDbType.NText: return typeof(string);
                case SqlDbType.NVarChar: return typeof(string);
                case SqlDbType.Real: return typeof(float);
                case SqlDbType.SmallDateTime: return typeof(DateTime);
                case SqlDbType.SmallInt: return typeof(short);
                case SqlDbType.SmallMoney: return typeof(decimal);
                case SqlDbType.Text: return typeof(string);
                case SqlDbType.Time: return typeof(TimeSpan);
                case SqlDbType.Timestamp: return typeof(byte[]);
                case SqlDbType.TinyInt: return typeof(byte);
                case SqlDbType.UniqueIdentifier: return typeof(Guid);
                case SqlDbType.VarBinary: return typeof(byte[]);
                case SqlDbType.VarChar: return typeof(string);
                case SqlDbType.Xml: return typeof(string);
                default: throw new ArgumentOutOfRangeException(nameof(sqlDbType), sqlDbType, null);
            }
        }

        [HttpPost]
        public IActionResult ExecuteProcedure(string procedureName,
    [Bind(Prefix = "Parameters")] List<StoredProcedureParameter> parameters)
        {
            try
            {
                using (var connection = new SqlConnection(_configuration.GetConnectionString("ManufacturingDB")))
                {
                    connection.Open();

                    using (var command = new SqlCommand(procedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        if (parameters != null)
                        {
                            foreach (var parameter in parameters)
                            {
                                var sqlDbType = GetSqlDbType(parameter.Type);
                                var type = GetTypeFromSqlDbType(sqlDbType);


                                object parameterValue = string.IsNullOrEmpty(parameter.Value)
                                    ? DBNull.Value
                                    : Convert.ChangeType(parameter.Value, type);

                                command.Parameters.AddWithValue(parameter.Name, parameterValue);
                            }
                        }


                        using (var reader = command.ExecuteReader())
                        {
                            var dataTable = new DataTable();
                            dataTable.Load(reader);

                            ViewBag.ProcedureResult = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = $"������� ��� ��������� ���������: {ex.Message}";
            }

            return View("Procedure", new StoredProcedureViewModel
            {
                Name = procedureName,
                Parameters = parameters
            });
        }


        private SqlDbType GetSqlDbType(string type)
        {
            switch (type.ToLower())
            {
                case "int": return SqlDbType.Int;
                case "varchar": return SqlDbType.VarChar;
                case "nvarchar": return SqlDbType.NVarChar;
                case "date": return SqlDbType.Date;
                case "datetime": return SqlDbType.DateTime;

                default: return SqlDbType.NVarChar;
            }
        }

        [HttpPost]
        public IActionResult ExecuteFunction(string functionName,
     [Bind(Prefix = "Parameters")] List<StoredProcedureParameter> parameters)
        {
            try
            {
                using (var connection = new SqlConnection(_configuration.GetConnectionString("ManufacturingDB")))
                {
                    connection.Open();

                    var sqlQuery = $"SELECT * FROM dbo.{functionName}(";

                    if (parameters != null && parameters.Any())
                    {
                        var parameterNames = parameters.Select((p, index) => $"@param{index}");
                        sqlQuery += string.Join(", ", parameterNames);
                        sqlQuery += ")";
                    }
                    else
                    {
                        sqlQuery += ")";
                    }

                    using (var command = new SqlCommand(sqlQuery, connection))
                    {
                        if (parameters != null)
                        {
                            for (int i = 0; i < parameters.Count; i++)
                            {
                                var parameter = parameters[i];
                                var sqlDbType = GetSqlDbType(parameter.Type);
                                var type = GetTypeFromSqlDbType(sqlDbType);

                                command.Parameters.Add(new System.Data.SqlClient.SqlParameter($"@param{i}", sqlDbType)
                                {
                                    Value = string.IsNullOrEmpty(parameter.Value)
                                        ? DBNull.Value
                                        : Convert.ChangeType(parameter.Value, type)
                                });
                            }
                        }


                        using (var reader = command.ExecuteReader())
                        {
                            var dataTable = new DataTable();
                            dataTable.Load(reader);
                            ViewBag.FunctionResult = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = $"������� ��� ��������� �������: {ex.Message}";
            }

            return View("Function", new FunctionViewModel
            {
                Name = functionName,
                Parameters = parameters
            });
        }
    }
}