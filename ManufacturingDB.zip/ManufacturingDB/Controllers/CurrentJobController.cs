using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class CurrentJobController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public CurrentJobController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: CurrentJob
        public async Task<IActionResult> Index()
        {
            var manufacturingDBContext = _context.CurrentJobs.Include(c => c.IdEmployeeNavigation).Include(c => c.IdPositionNavigation).Include(c => c.IdProfessionNavigation).Include(c => c.IdSectionNavigation);
            return View(await manufacturingDBContext.ToListAsync());
        }

        // GET: CurrentJob/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var currentJob = await _context.CurrentJobs
                .Include(c => c.IdEmployeeNavigation)
                .Include(c => c.IdPositionNavigation)
                .Include(c => c.IdProfessionNavigation)
                .Include(c => c.IdSectionNavigation)
                .FirstOrDefaultAsync(m => m.IdCurrentJob == id);
            if (currentJob == null)
            {
                return NotFound();
            }

            return View(currentJob);
        }

        // GET: CurrentJob/Create
        public IActionResult Create()
        {
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee");
            ViewData["IdPosition"] = new SelectList(_context.Positions, "IdPosition", "IdPosition");
            ViewData["IdProfession"] = new SelectList(_context.Professions, "IdProfession", "IdProfession");
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection");
            return View();
        }

        // POST: CurrentJob/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdCurrentJob,IdEmployee,EmployeeType,IdProfession,IdPosition,IdSection,StartDate,EndDate")] CurrentJob currentJob)
        {
            if (ModelState.IsValid)
            {
                _context.Add(currentJob);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", currentJob.IdEmployee);
            ViewData["IdPosition"] = new SelectList(_context.Positions, "IdPosition", "IdPosition", currentJob.IdPosition);
            ViewData["IdProfession"] = new SelectList(_context.Professions, "IdProfession", "IdProfession", currentJob.IdProfession);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", currentJob.IdSection);
            return View(currentJob);
        }

        // GET: CurrentJob/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var currentJob = await _context.CurrentJobs.FindAsync(id);
            if (currentJob == null)
            {
                return NotFound();
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", currentJob.IdEmployee);
            ViewData["IdPosition"] = new SelectList(_context.Positions, "IdPosition", "IdPosition", currentJob.IdPosition);
            ViewData["IdProfession"] = new SelectList(_context.Professions, "IdProfession", "IdProfession", currentJob.IdProfession);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", currentJob.IdSection);
            return View(currentJob);
        }

        // POST: CurrentJob/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdCurrentJob,IdEmployee,EmployeeType,IdProfession,IdPosition,IdSection,StartDate,EndDate")] CurrentJob currentJob)
        {
            if (id != currentJob.IdCurrentJob)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(currentJob);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CurrentJobExists(currentJob.IdCurrentJob))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEmployee"] = new SelectList(_context.Employees, "IdEmployee", "IdEmployee", currentJob.IdEmployee);
            ViewData["IdPosition"] = new SelectList(_context.Positions, "IdPosition", "IdPosition", currentJob.IdPosition);
            ViewData["IdProfession"] = new SelectList(_context.Professions, "IdProfession", "IdProfession", currentJob.IdProfession);
            ViewData["IdSection"] = new SelectList(_context.Sections, "IdSection", "IdSection", currentJob.IdSection);
            return View(currentJob);
        }

        // GET: CurrentJob/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var currentJob = await _context.CurrentJobs
                .Include(c => c.IdEmployeeNavigation)
                .Include(c => c.IdPositionNavigation)
                .Include(c => c.IdProfessionNavigation)
                .Include(c => c.IdSectionNavigation)
                .FirstOrDefaultAsync(m => m.IdCurrentJob == id);
            if (currentJob == null)
            {
                return NotFound();
            }

            return View(currentJob);
        }

        // POST: CurrentJob/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var currentJob = await _context.CurrentJobs.FindAsync(id);
            if (currentJob != null)
            {
                _context.CurrentJobs.Remove(currentJob);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CurrentJobExists(int id)
        {
            return _context.CurrentJobs.Any(e => e.IdCurrentJob == id);
        }
    }
}
