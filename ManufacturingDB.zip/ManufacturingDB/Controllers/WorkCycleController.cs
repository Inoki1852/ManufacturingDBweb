using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ManufacturingDB.Models;

namespace ManufacturingDB.Controllers
{
    public class WorkCycleController : Controller
    {
        private readonly ManufacturingDBContext _context;

        public WorkCycleController(ManufacturingDBContext context)
        {
            _context = context;
        }

        // GET: WorkCycle
        public async Task<IActionResult> Index()
        {
            return View(await _context.WorkCycles.ToListAsync());
        }

        // GET: WorkCycle/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workCycle = await _context.WorkCycles
                .FirstOrDefaultAsync(m => m.IdCycle == id);
            if (workCycle == null)
            {
                return NotFound();
            }

            return View(workCycle);
        }

        // GET: WorkCycle/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: WorkCycle/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdCycle,CycleName,CycleDescription")] WorkCycle workCycle)
        {
            if (ModelState.IsValid)
            {
                _context.Add(workCycle);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(workCycle);
        }

        // GET: WorkCycle/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workCycle = await _context.WorkCycles.FindAsync(id);
            if (workCycle == null)
            {
                return NotFound();
            }
            return View(workCycle);
        }

        // POST: WorkCycle/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdCycle,CycleName,CycleDescription")] WorkCycle workCycle)
        {
            if (id != workCycle.IdCycle)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(workCycle);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WorkCycleExists(workCycle.IdCycle))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(workCycle);
        }

        // GET: WorkCycle/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workCycle = await _context.WorkCycles
                .FirstOrDefaultAsync(m => m.IdCycle == id);
            if (workCycle == null)
            {
                return NotFound();
            }

            return View(workCycle);
        }

        // POST: WorkCycle/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var workCycle = await _context.WorkCycles.FindAsync(id);
            if (workCycle != null)
            {
                _context.WorkCycles.Remove(workCycle);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool WorkCycleExists(int id)
        {
            return _context.WorkCycles.Any(e => e.IdCycle == id);
        }
    }
}
