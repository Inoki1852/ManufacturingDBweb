﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Section")]
public partial class Section
{
    [Key]
    [Column("id_section")]
    public int IdSection { get; set; }

    [Column("section_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string SectionName { get; set; } = null!;

    [Column("id_workshop")]
    public int? IdWorkshop { get; set; }

    [InverseProperty("IdSectionNavigation")]
    public virtual ICollection<CurrentJob> CurrentJobs { get; set; } = new List<CurrentJob>();

    [ForeignKey("IdWorkshop")]
    [InverseProperty("Sections")]
    public virtual Workshop? IdWorkshopNavigation { get; set; }

    [InverseProperty("IdSectionNavigation")]
    public virtual ICollection<Manufacturing> Manufacturings { get; set; } = new List<Manufacturing>();

    [InverseProperty("IdSectionNavigation")]
    public virtual ICollection<Master> Masters { get; set; } = new List<Master>();

    [InverseProperty("IdSectionNavigation")]
    public virtual ICollection<Team> Teams { get; set; } = new List<Team>();
}
