﻿using static ManufacturingDB.Controllers.HomeController;

namespace ManufacturingDB.Models
{
	public class StoredProcedureViewModel
	{
		public string? Name { get; set; }
		public List<StoredProcedureParameter>? Parameters { get; set; }
	}
}
