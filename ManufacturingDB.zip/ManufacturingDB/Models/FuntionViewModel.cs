﻿using static ManufacturingDB.Controllers.HomeController;

namespace ManufacturingDB.Models
{
    public class FunctionViewModel
    {
        public string? Name { get; set; }
        public List<StoredProcedureParameter>? Parameters { get; set; }
    }
}
