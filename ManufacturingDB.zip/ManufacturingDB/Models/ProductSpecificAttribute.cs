﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[PrimaryKey("IdProduct", "IdAttributeType")]
[Table("ProductSpecificAttribute")]
public partial class ProductSpecificAttribute
{
    [Key]
    [Column("id_product")]
    public int IdProduct { get; set; }

    [Key]
    [Column("id_attribute_type")]
    public int IdAttributeType { get; set; }

    [Column("value")]
    [StringLength(255)]
    [Unicode(false)]
    public string? Value { get; set; }

    [ForeignKey("IdAttributeType")]
    [InverseProperty("ProductSpecificAttributes")]
    public virtual AttributeType IdAttributeTypeNavigation { get; set; } = null!;

    [ForeignKey("IdProduct")]
    [InverseProperty("ProductSpecificAttributes")]
    public virtual Product IdProductNavigation { get; set; } = null!;
}
