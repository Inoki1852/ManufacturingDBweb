﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[PrimaryKey("IdEmployee", "IdAttributeType")]
[Table("EmployeeSpecificAttribute")]
public partial class EmployeeSpecificAttribute
{
    [Key]
    [Column("id_employee")]
    public int IdEmployee { get; set; }

    [Key]
    [Column("id_attribute_type")]
    public int IdAttributeType { get; set; }

    [Column("attribute_value")]
    [StringLength(255)]
    [Unicode(false)]
    public string? AttributeValue { get; set; }

    [ForeignKey("IdAttributeType")]
    [InverseProperty("EmployeeSpecificAttributes")]
    public virtual AttributeType IdAttributeTypeNavigation { get; set; } = null!;

    [ForeignKey("IdEmployee")]
    [InverseProperty("EmployeeSpecificAttributes")]
    public virtual Employee IdEmployeeNavigation { get; set; } = null!;
}
