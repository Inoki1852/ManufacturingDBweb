﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("CurrentJob")]
public partial class CurrentJob
{
    [Key]
    [Column("id_current_job")]
    public int IdCurrentJob { get; set; }

    [Column("id_employee")]
    public int IdEmployee { get; set; }

    [Column("employee_type")]
    [StringLength(50)]
    [Unicode(false)]
    public string EmployeeType { get; set; } = null!;

    [Column("id_profession")]
    public int? IdProfession { get; set; }

    [Column("id_position")]
    public int? IdPosition { get; set; }

    [Column("id_section")]
    public int? IdSection { get; set; }

    [Column("start_date")]
    public DateOnly? StartDate { get; set; }

    [Column("end_date")]
    public DateOnly? EndDate { get; set; }

    [ForeignKey("IdEmployee")]
    [InverseProperty("CurrentJobs")]
    public virtual Employee IdEmployeeNavigation { get; set; } = null!;

    [ForeignKey("IdPosition")]
    [InverseProperty("CurrentJobs")]
    public virtual Position? IdPositionNavigation { get; set; }

    [ForeignKey("IdProfession")]
    [InverseProperty("CurrentJobs")]
    public virtual Profession? IdProfessionNavigation { get; set; }

    [ForeignKey("IdSection")]
    [InverseProperty("CurrentJobs")]
    public virtual Section? IdSectionNavigation { get; set; }
}
