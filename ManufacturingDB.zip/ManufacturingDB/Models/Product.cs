﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Product")]
[Index("IdProductType", Name = "IX_Product_id_product_type")]
[Index("ProductName", Name = "IX_Product_product_name")]
public partial class Product
{
    [Key]
    [Column("id_product")]
    public int IdProduct { get; set; }

    [Column("product_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string ProductName { get; set; } = null!;

    [Column("id_product_type")]
    public int? IdProductType { get; set; }

    [Column("id_workshop")]
    public int? IdWorkshop { get; set; }

    [ForeignKey("IdProductType")]
    [InverseProperty("Products")]
    public virtual ProductType? IdProductTypeNavigation { get; set; }

    [ForeignKey("IdWorkshop")]
    [InverseProperty("Products")]
    public virtual Workshop? IdWorkshopNavigation { get; set; }

    [InverseProperty("IdProductNavigation")]
    public virtual ICollection<Manufacturing> Manufacturings { get; set; } = new List<Manufacturing>();

    [InverseProperty("IdProductNavigation")]
    public virtual ICollection<ProductAccounting> ProductAccountings { get; set; } = new List<ProductAccounting>();

    [InverseProperty("IdProductNavigation")]
    public virtual ICollection<ProductSpecificAttribute> ProductSpecificAttributes { get; set; } = new List<ProductSpecificAttribute>();

    [InverseProperty("IdProductNavigation")]
    public virtual ICollection<Testing> Testings { get; set; } = new List<Testing>();
}
