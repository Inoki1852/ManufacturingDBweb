﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

public partial class Equipment
{
    [Key]
    [Column("id_equipment")]
    public int IdEquipment { get; set; }

    [Column("equipment_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string EquipmentName { get; set; } = null!;

    [Column("equipment_type")]
    [StringLength(50)]
    [Unicode(false)]
    public string EquipmentType { get; set; } = null!;

    [Column("id_laboratory")]
    public int? IdLaboratory { get; set; }

    [ForeignKey("IdLaboratory")]
    [InverseProperty("Equipment")]
    public virtual TestingLaboratory? IdLaboratoryNavigation { get; set; }

    [InverseProperty("IdEquipmentNavigation")]
    public virtual ICollection<TestingEquipment> TestingEquipments { get; set; } = new List<TestingEquipment>();
}
