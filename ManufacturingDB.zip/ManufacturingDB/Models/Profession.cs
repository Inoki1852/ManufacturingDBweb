﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Profession")]
public partial class Profession
{
    [Key]
    [Column("id_profession")]
    public int IdProfession { get; set; }

    [Column("profession_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string ProfessionName { get; set; } = null!;

    [InverseProperty("IdProfessionNavigation")]
    public virtual ICollection<CurrentJob> CurrentJobs { get; set; } = new List<CurrentJob>();
}
