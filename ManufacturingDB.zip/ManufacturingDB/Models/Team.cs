﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Team")]
public partial class Team
{
    [Key]
    [Column("id_team")]
    public int IdTeam { get; set; }

    [Column("team_leader")]
    public int? TeamLeader { get; set; }

    [Column("id_section")]
    public int? IdSection { get; set; }

    [ForeignKey("IdSection")]
    [InverseProperty("Teams")]
    public virtual Section? IdSectionNavigation { get; set; }

    [InverseProperty("IdTeamNavigation")]
    public virtual ICollection<Manufacturing> Manufacturings { get; set; } = new List<Manufacturing>();

    [ForeignKey("TeamLeader")]
    [InverseProperty("Teams")]
    public virtual Employee? TeamLeaderNavigation { get; set; }

    [InverseProperty("IdTeamNavigation")]
    public virtual ICollection<TeamMember> TeamMembers { get; set; } = new List<TeamMember>();
}
