﻿namespace ManufacturingDB.Models
{
    public class Function
    {
        public string? Name { get; set; }
        public List<SqlParameter> Parameters { get; set; } = new List<SqlParameter>();
    }
}
