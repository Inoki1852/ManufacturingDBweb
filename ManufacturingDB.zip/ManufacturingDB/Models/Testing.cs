﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Testing")]
[Index("IdProduct", Name = "IX_Testing_id_product")]
public partial class Testing
{
    [Key]
    [Column("id_testing")]
    public int IdTesting { get; set; }

    [Column("id_product")]
    public int? IdProduct { get; set; }

    [Column("id_laboratory")]
    public int? IdLaboratory { get; set; }

    [Column("date_start")]
    public DateOnly DateStart { get; set; }

    [Column("date_end")]
    public DateOnly? DateEnd { get; set; }

    [Column("result_testing")]
    [StringLength(50)]
    [Unicode(false)]
    public string? ResultTesting { get; set; }

    [Column("id_employee")]
    public int? IdEmployee { get; set; }

    [ForeignKey("IdEmployee")]
    [InverseProperty("Testings")]
    public virtual Employee? IdEmployeeNavigation { get; set; }

    [ForeignKey("IdLaboratory")]
    [InverseProperty("Testings")]
    public virtual TestingLaboratory? IdLaboratoryNavigation { get; set; }

    [ForeignKey("IdProduct")]
    [InverseProperty("Testings")]
    public virtual Product? IdProductNavigation { get; set; }

    [InverseProperty("IdTestingNavigation")]
    public virtual TestingEquipment? TestingEquipment { get; set; }
}
