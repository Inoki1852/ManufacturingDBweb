﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("TestingLaboratory")]
public partial class TestingLaboratory
{
    [Key]
    [Column("id_laboratory")]
    public int IdLaboratory { get; set; }

    [Column("laboratory_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string LaboratoryName { get; set; } = null!;

    [InverseProperty("IdLaboratoryNavigation")]
    public virtual ICollection<Equipment> Equipment { get; set; } = new List<Equipment>();

    [InverseProperty("IdLaboratoryNavigation")]
    public virtual ICollection<Testing> Testings { get; set; } = new List<Testing>();
}
