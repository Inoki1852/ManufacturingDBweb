﻿namespace ManufacturingDB.Models
{
	public class StoredProcedure
	{
		public string? Name { get; set; }
		public List<SqlParameter> Parameters { get; set; } = new List<SqlParameter>();
	}
}
