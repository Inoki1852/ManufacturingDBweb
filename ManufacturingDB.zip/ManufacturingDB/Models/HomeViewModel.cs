﻿namespace ManufacturingDB.Models
{
	public class HomeViewModel
	{
		public List<string>? TableNames { get; set; }
		public List<StoredProcedure>? StoredProcedures { get; set; }
		public List<Function>? Functions { get; set; }
	}
}

