﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("ProductAccounting")]
public partial class ProductAccounting
{
    [Key]
    [Column("id_accounting")]
    public int IdAccounting { get; set; }

    [Column("id_product")]
    public int? IdProduct { get; set; }

    [Column("production_date")]
    public DateOnly ProductionDate { get; set; }

    [Column("quantity")]
    public int Quantity { get; set; }

    [Column("details")]
    [StringLength(255)]
    [Unicode(false)]
    public string? Details { get; set; }

    [ForeignKey("IdProduct")]
    [InverseProperty("ProductAccountings")]
    public virtual Product? IdProductNavigation { get; set; }
}
