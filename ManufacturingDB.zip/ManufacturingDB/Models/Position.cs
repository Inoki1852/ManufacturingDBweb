﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Position")]
public partial class Position
{
    [Key]
    [Column("id_position")]
    public int IdPosition { get; set; }

    [Column("position_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string PositionName { get; set; } = null!;

    [InverseProperty("IdPositionNavigation")]
    public virtual ICollection<CurrentJob> CurrentJobs { get; set; } = new List<CurrentJob>();
}
