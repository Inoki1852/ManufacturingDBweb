﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("TeamMember")]
public partial class TeamMember
{
    [Key]
    [Column("id_team_member")]
    public int IdTeamMember { get; set; }

    [Column("id_employee")]
    public int IdEmployee { get; set; }

    [Column("id_team")]
    public int IdTeam { get; set; }

    [ForeignKey("IdEmployee")]
    [InverseProperty("TeamMembers")]
    public virtual Employee IdEmployeeNavigation { get; set; } = null!;

    [ForeignKey("IdTeam")]
    [InverseProperty("TeamMembers")]
    public virtual Team IdTeamNavigation { get; set; } = null!;
}
