﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Employee")]
public partial class Employee
{
    [Key]
    [Column("id_employee")]
    public int IdEmployee { get; set; }

    [Column("first_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string FirstName { get; set; } = null!;

    [Column("last_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string LastName { get; set; } = null!;

    [InverseProperty("IdEmployeeNavigation")]
    public virtual ICollection<CurrentJob> CurrentJobs { get; set; } = new List<CurrentJob>();

    [InverseProperty("IdEmployeeNavigation")]
    public virtual ICollection<EmployeeSpecificAttribute> EmployeeSpecificAttributes { get; set; } = new List<EmployeeSpecificAttribute>();

    [InverseProperty("IdEmployeeNavigation")]
    public virtual ICollection<Master> Masters { get; set; } = new List<Master>();

    [InverseProperty("IdEmployeeNavigation")]
    public virtual ICollection<PersonnelMovement> PersonnelMovements { get; set; } = new List<PersonnelMovement>();

    [InverseProperty("IdEmployeeNavigation")]
    public virtual ICollection<TeamMember> TeamMembers { get; set; } = new List<TeamMember>();

    [InverseProperty("TeamLeaderNavigation")]
    public virtual ICollection<Team> Teams { get; set; } = new List<Team>();

    [InverseProperty("IdEmployeeNavigation")]
    public virtual ICollection<Testing> Testings { get; set; } = new List<Testing>();

    [InverseProperty("HeadOfWorkshopNavigation")]
    public virtual ICollection<Workshop> Workshops { get; set; } = new List<Workshop>();
}
