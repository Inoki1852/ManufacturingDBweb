﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Workshop")]
public partial class Workshop
{
    [Key]
    [Column("id_workshop")]
    public int IdWorkshop { get; set; }

    [Column("workshop_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string WorkshopName { get; set; } = null!;

    [Column("head_of_workshop")]
    public int? HeadOfWorkshop { get; set; }

    [ForeignKey("HeadOfWorkshop")]
    [InverseProperty("Workshops")]
    public virtual Employee? HeadOfWorkshopNavigation { get; set; }

    [InverseProperty("IdWorkshopNavigation")]
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();

    [InverseProperty("IdWorkshopNavigation")]
    public virtual ICollection<Section> Sections { get; set; } = new List<Section>();
}
