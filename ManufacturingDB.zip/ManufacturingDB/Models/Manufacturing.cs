﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Manufacturing")]
[Index("IdProduct", Name = "IX_Manufacturing_id_product")]
[Index("IdSection", Name = "IX_Manufacturing_id_section")]
public partial class Manufacturing
{
	[Key]
	[Column("id_manufacturing")]
	public int IdManufacturing { get; set; }

	[Column("id_product")]
	public int? IdProduct { get; set; }

	[Column("id_section")]
	public int? IdSection { get; set; }

	[Column("id_team")]
	public int? IdTeam { get; set; }

	[Column("id_cycle")]
	public int? IdCycle { get; set; }

	[Column("time_start")]
	public DateOnly TimeStart { get; set; }

	[Column("time_end")]
	public DateOnly? TimeEnd { get; set; }

	[ForeignKey("IdCycle")]
	[InverseProperty("Manufacturings")]
	public virtual WorkCycle? IdCycleNavigation { get; set; }

	[ForeignKey("IdProduct")]
	[InverseProperty("Manufacturings")]
	public virtual Product? IdProductNavigation { get; set; }

	[ForeignKey("IdSection")]
	[InverseProperty("Manufacturings")]
	public virtual Section? IdSectionNavigation { get; set; }

	[ForeignKey("IdTeam")]
	[InverseProperty("Manufacturings")]
	public virtual Team? IdTeamNavigation { get; set; }
}
