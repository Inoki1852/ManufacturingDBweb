﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("WorkCycle")]
public partial class WorkCycle
{
    [Key]
    [Column("id_cycle")]
    public int IdCycle { get; set; }

    [Column("cycle_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string CycleName { get; set; } = null!;

    [Column("cycle_description")]
    [StringLength(255)]
    [Unicode(false)]
    public string? CycleDescription { get; set; }

    [InverseProperty("IdCycleNavigation")]
    public virtual ICollection<Manufacturing> Manufacturings { get; set; } = new List<Manufacturing>();
}
