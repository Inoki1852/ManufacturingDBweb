﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("Master")]
public partial class Master
{
    [Key]
    [Column("id_master")]
    public int IdMaster { get; set; }

    [Column("id_employee")]
    public int? IdEmployee { get; set; }

    [Column("id_section")]
    public int? IdSection { get; set; }

    [ForeignKey("IdEmployee")]
    [InverseProperty("Masters")]
    public virtual Employee? IdEmployeeNavigation { get; set; }

    [ForeignKey("IdSection")]
    [InverseProperty("Masters")]
    public virtual Section? IdSectionNavigation { get; set; }
}
