﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("PersonnelMovement")]
public partial class PersonnelMovement
{
    [Key]
    [Column("id_movement")]
    public int IdMovement { get; set; }

    [Column("id_employee")]
    public int? IdEmployee { get; set; }

    [Column("movement_type")]
    [StringLength(50)]
    [Unicode(false)]
    public string MovementType { get; set; } = null!;

    [Column("movement_date")]
    public DateOnly MovementDate { get; set; }

    [Column("details")]
    [StringLength(255)]
    [Unicode(false)]
    public string? Details { get; set; }

    [ForeignKey("IdEmployee")]
    [InverseProperty("PersonnelMovements")]
    public virtual Employee? IdEmployeeNavigation { get; set; }
}
