﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("TestingEquipment")]
public partial class TestingEquipment
{
    [Key]
    [Column("id_testing")]
    public int IdTesting { get; set; }

    [Column("id_equipment")]
    public int IdEquipment { get; set; }

    [ForeignKey("IdEquipment")]
    [InverseProperty("TestingEquipments")]
    public virtual Equipment IdEquipmentNavigation { get; set; } = null!;

    [ForeignKey("IdTesting")]
    [InverseProperty("TestingEquipment")]
    public virtual Testing IdTestingNavigation { get; set; } = null!;
}
