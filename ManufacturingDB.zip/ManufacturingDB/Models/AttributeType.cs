﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("AttributeType")]
public partial class AttributeType
{
    [Key]
    [Column("id_attribute_type")]
    public int IdAttributeType { get; set; }

    [Column("type_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string TypeName { get; set; } = null!;

    [Column("category")]
    [StringLength(50)]
    [Unicode(false)]
    public string Category { get; set; } = null!;

    [InverseProperty("IdAttributeTypeNavigation")]
    public virtual ICollection<EmployeeSpecificAttribute> EmployeeSpecificAttributes { get; set; } = new List<EmployeeSpecificAttribute>();

    [InverseProperty("IdAttributeTypeNavigation")]
    public virtual ICollection<ProductSpecificAttribute> ProductSpecificAttributes { get; set; } = new List<ProductSpecificAttribute>();
}
