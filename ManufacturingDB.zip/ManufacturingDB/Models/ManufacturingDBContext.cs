﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

public partial class ManufacturingDBContext : DbContext
{
	public ManufacturingDBContext()
	{
	}

	public ManufacturingDBContext(DbContextOptions<ManufacturingDBContext> options)
		: base(options)
	{
	}

	public virtual DbSet<AttributeType> AttributeTypes { get; set; }

	public virtual DbSet<CurrentJob> CurrentJobs { get; set; }

	public virtual DbSet<Employee> Employees { get; set; }

	public virtual DbSet<EmployeeSpecificAttribute> EmployeeSpecificAttributes { get; set; }

	public virtual DbSet<Equipment> Equipment { get; set; }

	public virtual DbSet<Manufacturing> Manufacturings { get; set; }

	public virtual DbSet<Master> Masters { get; set; }

	public virtual DbSet<PersonnelMovement> PersonnelMovements { get; set; }

	public virtual DbSet<Position> Positions { get; set; }

	public virtual DbSet<Product> Products { get; set; }

	public virtual DbSet<ProductAccounting> ProductAccountings { get; set; }

	public virtual DbSet<ProductSpecificAttribute> ProductSpecificAttributes { get; set; }

	public virtual DbSet<ProductType> ProductTypes { get; set; }

	public virtual DbSet<Profession> Professions { get; set; }

	public virtual DbSet<Section> Sections { get; set; }

	public virtual DbSet<Team> Teams { get; set; }

	public virtual DbSet<TeamMember> TeamMembers { get; set; }

	public virtual DbSet<Testing> Testings { get; set; }

	public virtual DbSet<TestingEquipment> TestingEquipments { get; set; }

	public virtual DbSet<TestingLaboratory> TestingLaboratories { get; set; }

	public virtual DbSet<WorkCycle> WorkCycles { get; set; }

	public virtual DbSet<Workshop> Workshops { get; set; }

	protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
		=> optionsBuilder.UseSqlServer("Server=localhost;Database=ManufacturingDB;Encrypt=False;TrustServerCertificate=True;Trusted_Connection=True;");

	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		modelBuilder.Entity<AttributeType>(entity =>
		{
			entity.HasKey(e => e.IdAttributeType).HasName("PK__Attribut__A14AD313E27E91B1");
		});

		modelBuilder.Entity<CurrentJob>(entity =>
		{
			entity.HasKey(e => e.IdCurrentJob).HasName("PK__CurrentJ__4E8F335FEEA6AEF2");

			entity.ToTable("CurrentJob", tb => tb.HasTrigger("trg_check_current_job_update"));

			entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.CurrentJobs).HasConstraintName("FK__CurrentJo__id_em__160F4887");

			entity.HasOne(d => d.IdPositionNavigation).WithMany(p => p.CurrentJobs).HasConstraintName("FK__CurrentJo__id_po__14270015");

			entity.HasOne(d => d.IdProfessionNavigation).WithMany(p => p.CurrentJobs).HasConstraintName("FK__CurrentJo__id_pr__1332DBDC");

			entity.HasOne(d => d.IdSectionNavigation).WithMany(p => p.CurrentJobs).HasConstraintName("FK__CurrentJo__id_se__151B244E");
		});

		modelBuilder.Entity<Employee>(entity =>
		{
			entity.HasKey(e => e.IdEmployee).HasName("PK__Employee__F807679C18B35E3F");
		});

		modelBuilder.Entity<EmployeeSpecificAttribute>(entity =>
		{
			entity.HasKey(e => new { e.IdEmployee, e.IdAttributeType }).HasName("PK__Employee__D213CAADB086570A");

			entity.HasOne(d => d.IdAttributeTypeNavigation).WithMany(p => p.EmployeeSpecificAttributes).HasConstraintName("FK__Employee___id_at__7B5B524B");

			entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.EmployeeSpecificAttributes).HasConstraintName("FK__Employee___id_em__7A672E12");
		});

		modelBuilder.Entity<Equipment>(entity =>
		{
			entity.HasKey(e => e.IdEquipment).HasName("PK__Equipmen__D745C9DF8A29F3EE");

			entity.HasOne(d => d.IdLaboratoryNavigation).WithMany(p => p.Equipment)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Equipment__id_la__4316F928");
		});

		modelBuilder.Entity<Manufacturing>(entity =>
		{
			entity.HasKey(e => e.IdManufacturing).HasName("PK__Manufact__75419793A07D7AEF");

			entity.HasOne(d => d.IdCycleNavigation).WithMany(p => p.Manufacturings)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Manufactu__id_cy__66603565");

			entity.HasOne(d => d.IdProductNavigation).WithMany(p => p.Manufacturings)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Manufactu__id_pr__6383C8BA");

			entity.HasOne(d => d.IdSectionNavigation).WithMany(p => p.Manufacturings)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Manufactu__id_se__6477ECF3");

			entity.HasOne(d => d.IdTeamNavigation).WithMany(p => p.Manufacturings).HasConstraintName("FK__Manufactu__id_te__656C112C");
		});

		modelBuilder.Entity<Master>(entity =>
		{
			entity.HasKey(e => e.IdMaster).HasName("PK__Master__A5148503D9D010EA");

			entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.Masters)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Master__id_emplo__5AEE82B9");

			entity.HasOne(d => d.IdSectionNavigation).WithMany(p => p.Masters)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Master__id_secti__5BE2A6F2");
		});

		modelBuilder.Entity<PersonnelMovement>(entity =>
		{
			entity.HasKey(e => e.IdMovement).HasName("PK__Personne__465F1AE4CC1D3A65");

			entity.ToTable("PersonnelMovement", tb =>
				{
					tb.HasTrigger("UpdateEndDate");
					tb.HasTrigger("trg_check_personnel_movement");
				});

			entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.PersonnelMovements)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Personnel__id_em__70DDC3D8");
		});

		modelBuilder.Entity<Position>(entity =>
		{
			entity.HasKey(e => e.IdPosition).HasName("PK__Position__D652893DB4227371");
		});

		modelBuilder.Entity<Product>(entity =>
		{
			entity.HasKey(e => e.IdProduct).HasName("PK__Product__BA39E84F6E1EA456");

			entity.HasOne(d => d.IdProductTypeNavigation).WithMany(p => p.Products)
				.OnDelete(DeleteBehavior.SetNull)
				.HasConstraintName("FK__Product__id_prod__571DF1D5");

			entity.HasOne(d => d.IdWorkshopNavigation).WithMany(p => p.Products)
				.OnDelete(DeleteBehavior.SetNull)
				.HasConstraintName("FK__Product__id_work__5812160E");
		});

		modelBuilder.Entity<ProductAccounting>(entity =>
		{
			entity.HasKey(e => e.IdAccounting).HasName("PK__Product___121ACA57E6F217A4");

			entity.HasOne(d => d.IdProductNavigation).WithMany(p => p.ProductAccountings)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Product_a__id_pr__73BA3083");
		});

		modelBuilder.Entity<ProductSpecificAttribute>(entity =>
		{
			entity.HasKey(e => new { e.IdProduct, e.IdAttributeType }).HasName("PK__Product___902D457E6E025C42");

			entity.HasOne(d => d.IdAttributeTypeNavigation).WithMany(p => p.ProductSpecificAttributes).HasConstraintName("FK__Product_s__id_at__778AC167");

			entity.HasOne(d => d.IdProductNavigation).WithMany(p => p.ProductSpecificAttributes).HasConstraintName("FK__Product_s__id_pr__76969D2E");
		});

		modelBuilder.Entity<ProductType>(entity =>
		{
			entity.HasKey(e => e.IdProductType).HasName("PK__Product___92422128415EF0C2");
		});

		modelBuilder.Entity<Profession>(entity =>
		{
			entity.HasKey(e => e.IdProfession).HasName("PK__Professi__F637922B9CE27137");
		});

		modelBuilder.Entity<Section>(entity =>
		{
			entity.HasKey(e => e.IdSection).HasName("PK__Section__83EAD1E8AF1C749C");

			entity.HasOne(d => d.IdWorkshopNavigation).WithMany(p => p.Sections)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Section__id_work__4AB81AF0");
		});

		modelBuilder.Entity<Team>(entity =>
		{
			entity.HasKey(e => e.IdTeam).HasName("PK__Team__C6D204E73E88370E");

			entity.HasOne(d => d.IdSectionNavigation).WithMany(p => p.Teams)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Team__id_section__5441852A");

			entity.HasOne(d => d.TeamLeaderNavigation).WithMany(p => p.Teams)
				.OnDelete(DeleteBehavior.SetNull)
				.HasConstraintName("FK__Team__team_leade__534D60F1");
		});

		modelBuilder.Entity<TeamMember>(entity =>
		{
			entity.HasKey(e => e.IdTeamMember).HasName("PK__TeamMemb__36EAACFC3BE11E98");

			entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.TeamMembers).HasConstraintName("FK__TeamMembe__id_em__18EBB532");

			entity.HasOne(d => d.IdTeamNavigation).WithMany(p => p.TeamMembers).HasConstraintName("FK__TeamMembe__id_te__19DFD96B");
		});

		modelBuilder.Entity<Testing>(entity =>
		{
			entity.HasKey(e => e.IdTesting).HasName("PK__Testing__EB1CDA1F4D94FFC1");

			entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.Testings)
				.OnDelete(DeleteBehavior.SetNull)
				.HasConstraintName("FK__Testing__id_empl__60A75C0F");

			entity.HasOne(d => d.IdLaboratoryNavigation).WithMany(p => p.Testings)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Testing__id_labo__5FB337D6");

			entity.HasOne(d => d.IdProductNavigation).WithMany(p => p.Testings)
				.OnDelete(DeleteBehavior.Cascade)
				.HasConstraintName("FK__Testing__id_prod__5EBF139D");
		});

		modelBuilder.Entity<TestingEquipment>(entity =>
		{
			entity.Property(e => e.IdTesting).ValueGeneratedNever();

			entity.HasOne(d => d.IdEquipmentNavigation).WithMany(p => p.TestingEquipments)
				.OnDelete(DeleteBehavior.ClientSetNull)
				.HasConstraintName("FK__Testing_E__id_eq__6E01572D");

			entity.HasOne(d => d.IdTestingNavigation).WithOne(p => p.TestingEquipment).HasConstraintName("FK__Testing_E__id_te__6D0D32F4");
		});

		modelBuilder.Entity<TestingLaboratory>(entity =>
		{
			entity.HasKey(e => e.IdLaboratory).HasName("PK__Testing___88195A21D1624808");
		});

		modelBuilder.Entity<WorkCycle>(entity =>
		{
			entity.HasKey(e => e.IdCycle).HasName("PK__Work_cyc__307D7DAA28FF99A9");
		});

		modelBuilder.Entity<Workshop>(entity =>
		{
			entity.HasKey(e => e.IdWorkshop).HasName("PK__Workshop__6351C245D493D79F");

			entity.HasOne(d => d.HeadOfWorkshopNavigation).WithMany(p => p.Workshops)
				.OnDelete(DeleteBehavior.SetNull)
				.HasConstraintName("FK__Workshop__head_o__47DBAE45");
		});

		OnModelCreatingPartial(modelBuilder);
	}

	partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
