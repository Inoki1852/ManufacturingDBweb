﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ManufacturingDB.Models;

[Table("ProductType")]
public partial class ProductType
{
    [Key]
    [Column("id_product_type")]
    public int IdProductType { get; set; }

    [Column("type_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string TypeName { get; set; } = null!;

    [InverseProperty("IdProductTypeNavigation")]
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
